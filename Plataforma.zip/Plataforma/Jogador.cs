using Godot;
using System;

public partial class Jogador : CharacterBody2D
{
	private int jumpCount;
	private Vector2 velocity;
	private Vector2 direction;
	[Export]private int MaxJumps = 2;
	public Vector2 savePoint;
	[Export]public int maxHealth = 6;
	[Export]public int health = 6;
	[Export]public float Speed = 100.0f;
	[Export]public float JumpVelocity = -400.0f;
	[Export]public float JumpVelocityLow = -300.0f;
	[Export]public float JumpVelocityHigh = -400.0f;
	float jumpPressTime = 0.0f;
	const float JumpLowThreshold = 0.2f;
	private Control HUD;
	private AnimatedSprite2D animate;

	// Get the gravity from the project settings to be synced with RigidBody nodes.
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();


	public override void _Ready() {
		animate = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		//animate = GetNode<Control>("AnimatedSprite2D");
	} //fim do ready

	public override void _PhysicsProcess(double delta)
	{
		//inercia inicial
		velocity = Velocity;
		// Add the gravity.
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;

		// Handle Jump.			
		if (Input.IsActionJustPressed("Space"))
		{
			// Start measuring the time the spacebar is being held.
			jumpPressTime = 0.0f;
		}
		else if (Input.IsActionPressed("Space"))
		{
			// Continue measuring the time the spacebar is being held.
			animate.Play("jump_hold");
			jumpPressTime += (float)delta;
		}
		else if (Input.IsActionJustReleased("Space"))
		{
			animate.Play("jump_release");
			Jump(jumpPressTime);
			jumpPressTime = 0.0f;
		}

		// Get the input direction and handle the movement/deceleration.
		// As good practice, you should replace UI actions with custom gameplay actions.
		direction = Input.GetVector("Left", "Right", "Up", "Down");
		if (direction != Vector2.Zero)
		{
			if(Input.IsActionJustPressed("Down")){
				velocity.Y = direction.Y * Speed;
			}
			if(!IsOnFloor()){
				velocity.X = direction.X * (Speed/2);
			}else velocity.X = direction.X * Speed;
		}
		else
		{
			//velocity.X = 0;
			velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed*(float)(3*delta));
		}

		Velocity = velocity;
		MoveAndSlide();

		Animation(velocity);

		void Jump(float jumpPressTime){
			// GD.Print(jumpPressTime);
			if (IsOnFloor()){
				jumpCount = 0;
			}
			if (jumpCount < MaxJumps){
				if (jumpPressTime <= JumpLowThreshold){
					velocity.Y = JumpVelocityLow;
				}else{
					velocity.Y = JumpVelocityHigh;
				}
				jumpCount++;
			}
		}
	} //fim do process

	private void Animation(Vector2 velocity) {
		if (velocity.X != 0) {
			if(Input.IsActionJustReleased("Space")){
				//animate.Stop();
				animate.Play("jump_release");
			}
			else if(Input.IsActionPressed("Space")){
				//animate.Stop();
				animate.Play("jump_hold");
			}
			else if(Input.IsActionPressed("Down")){
				GD.Print(velocity);
				animate.Play("look_down_run");
			}else if(Input.IsActionPressed("Up")){
				GD.Print(velocity);
				animate.Play("look_up_run");
			}else if (!IsOnFloor()){
				//animate.Stop();
				animate.Play("airborne");
			}else
			animate.Play("run");
		} else {
			if(Input.IsActionJustReleased("Space")){
				animate.Play("jump_release");
			}
			else if(Input.IsActionPressed("Space")){
				animate.Play("jump_hold");
			}
			else if(Input.IsActionPressed("Down")){
				GD.Print(velocity);
				animate.Play("look_down_idle");
			}else if(Input.IsActionPressed("Up")){
				GD.Print(velocity);
				animate.Play("look_up_idle");
			}else if (!IsOnFloor()){
				animate.Play("airborne");
			}else
			animate.Play("idle");
		}

		// Scale=new Vector2(1,-1);

		//if(velocity.X=0){}
		if(velocity.X>0 && velocity.X!=0){
			animate.FlipH=true;
		}else if(velocity.X<0 && velocity.X!=0){
			animate.FlipH=false;
		}
	}

	public void newSavePoint(){
		savePoint=GlobalPosition;

	}

	public void ReturnToSavePoint(){
		GlobalPosition=savePoint;
	}
	
	public void increaseHealth(int heal){
		if(health==maxHealth){
			GD.Print("Já possui vida máxima!");
		}else if(health<maxHealth){
			health = health + heal;
			GD.Print("Vida Restaurada em " + heal.ToString() + " pontos!");
		}
	}
	
	public void reduceHealth(int damage){
		if(health==0){
			GD.Print("Você morreu!");
		}else if(health>0){
			GlobalPosition=savePoint;
			health = health - damage;
			GD.Print("Você perdeu " + damage.ToString() + " pontos de vida!");
		}
		
	}

} //fim da classe
