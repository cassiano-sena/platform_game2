using Godot;
using System;

public partial class Inimigo : Area2D
{

	private int x=0;
	private bool direita=true;

	public override void _Ready() {
	} //fim do ready

	public override void _PhysicsProcess(double delta)
	{
		GetNode<AnimatedSprite2D>("AnimatedSprite2D").Play("run");
		if(direita){
			GlobalPosition= GlobalPosition + new Vector2(1,0);
		}else{
			GlobalPosition= GlobalPosition - new Vector2(1,0);
		}
		if(x>=100){
			direita= !direita;
			x=0;
		}
		x++;
	} //fim do process
} //fim da classe
