using Godot;
using System;

public partial class mapa_2 : Node2D
{
	// Called when the node enters the scene tree for the first time.
	public Area2D Coin;
	public Area2D Coin2;
	public int coinCount=0;
	public AnimatedSprite2D animate;
	public override void _Ready()
	{
		Coin=GetNode<Area2D>("Coin");
		Coin2=GetNode<Area2D>("Coin2");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}
	public void _on_checkpoint_body_entered(Node2D body)
	{
		if(body is Jogador){
			((Jogador)body).newSavePoint();
			GD.Print("Checkpoint!");
			animate.Play("active");
		}
	}	
	
	//GetTree().CallGroup("GrupoJogador","LimiteDeQueda", 400);
	//GetTree().CallGroup("GrupoJogador","DefiniePontoInicial", new Vector2(0,0));
	//GetTree().CallGroup("GrupoJogador","Moedas", 4);
	//GetTree().CallGroup("GrupoJogador","DefineVida", 6);
	
	public void _on_coracao_body_entered(Node2D body)
	{
		if(body is Jogador){
			//pontos.IncreaseHealth();
			GD.Print("Vida Restaurada!");
			QueueFree();
		}	// Replace with function body.
	}
}
