using Godot;
using System;

public partial class Mapa_cassiano : Node2D
{
	public Area2D Coin;
	public Area2D Coin2;
	public Area2D Coin3;
	public Area2D Coin4;
	public int coinCount=0;
	public AnimatedSprite2D animate;
	// // Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		Coin=GetNode<Area2D>("Coin");
		Coin2=GetNode<Area2D>("Coin2");
		Coin3=GetNode<Area2D>("Coin3");
		Coin4=GetNode<Area2D>("Coin4");
	}

	//GetTree().CallGroup("GrupoJogador","LimiteDeQueda", 400);
	//GetTree().CallGroup("GrupoJogador","DefiniePontoInicial", new Vector2(0,0));
	//GetTree().CallGroup("GrupoJogador","Moedas", 4);
	//GetTree().CallGroup("GrupoJogador","DefineVida", 6);

	// // Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}
}


