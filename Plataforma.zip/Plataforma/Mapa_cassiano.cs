using Godot;
using System;

public partial class Mapa_cassiano : Node2D
{
	public Area2D Coin;
	public Area2D Coin2;
	public Area2D Coin3;
	public Area2D Coin4;
	public int coinCount=0;
	public AnimatedSprite2D animate;
	// // Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		Coin=GetNode<Area2D>("Coin");
		Coin2=GetNode<Area2D>("Coin2");
		Coin3=GetNode<Area2D>("Coin3");
		Coin4=GetNode<Area2D>("Coin4");
	}

	// // Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}
	
	
	
	public void _on_checkpoint_body_entered(Node2D body)
	{
		if(body is Jogador){
			((Jogador)body).newSavePoint();
			GD.Print("Checkpoint!");
			animate.Play("active");
		}
	}	
	
	public void _on_coin_collected(Node2D body)
	{
		coinCount++;
		if(coinCount>=4){
			GetTree().ChangeSceneToFile("mapa_1.tscn");
			coinCount=0;
		}
	}
	public void _on_coracao_body_entered(Node2D body)
	{
		if(body is Jogador){
			//pontos.IncreaseHealth();
			GD.Print("Vida Restaurada!");
			QueueFree();
		}	// Replace with function body.
	}
}


