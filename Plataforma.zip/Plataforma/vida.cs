using Godot;
using System;

public partial class vida : Control
{
	private AnimatedSprite2D animate;
	private CharacterBody2D Jogador;
	private Sprite2D coracao1;
	private Sprite2D coracao2;
	private Sprite2D coracao3;
	private Timer tempo;
	private int health;
	
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		coracao1 = GetNode<Sprite2D>("Coracao1");
		coracao2 = GetNode<Sprite2D>("Coracao2");
		coracao3 = GetNode<Sprite2D>("Coracao3");
		animate = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
		Jogador = GetNode<CharacterBody2D>("Jogador");
		Jogador jogador = GetNode<Jogador>("res://Jogador.cs");
		health = jogador.health;
		tempo = GetNode<Timer>("Timer");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		//tempo.Start();
		//if(tempo.TimeLeft<0.1f){
		//	changeHealthHUD();
		//}
		changeHealthHUD();
		
	}
	
	private void changeHealthHUD(){
		if(health==0){
			Texture2D newTexture = (Texture2D)ResourceLoader.Load("res://pixel_platformer/Jogador/empty.png");
			coracao1.Texture = newTexture;
		}else if(health==1){
			Texture2D newTexture = (Texture2D)ResourceLoader.Load("res://pixel_platformer/Jogador/half.png");
			coracao1.Texture = newTexture;
		}else if(health==2){
			Texture2D newTexture = (Texture2D)ResourceLoader.Load("res://pixel_platformer/Jogador/full.png");
			Texture2D newTexture2 = (Texture2D)ResourceLoader.Load("res://pixel_platformer/Jogador/empty.png");
			coracao1.Texture = newTexture;
			coracao2.Texture = newTexture2;
		}else if(health==3){
			Texture2D newTexture = (Texture2D)ResourceLoader.Load("res://pixel_platformer/Jogador/half.png");
			coracao2.Texture = newTexture;
		}else if(health==4){
			Texture2D newTexture = (Texture2D)ResourceLoader.Load("res://pixel_platformer/Jogador/full.png");
			Texture2D newTexture2 = (Texture2D)ResourceLoader.Load("res://pixel_platformer/Jogador/empty.png");
			coracao2.Texture = newTexture;
			coracao3.Texture = newTexture2;
		}else if(health==5){
			Texture2D newTexture = (Texture2D)ResourceLoader.Load("res://pixel_platformer/Jogador/half.png");
			//coracao1.Texture = newTexture;
			//coracao2.Texture = newTexture;
			coracao3.Texture = newTexture;
		}else if(health==6){
			Texture2D newTexture = (Texture2D)ResourceLoader.Load("res://pixel_platformer/Jogador/full.png");
			coracao1.Texture = newTexture;
			coracao2.Texture = newTexture;
			coracao3.Texture = newTexture;
		}
	}
	
	public void Dano(int dano){
		//if(Jogador.vida=6){
		//	coracao.animate;
		//}
	}
}
